-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "creativityLevel" TEXT NOT NULL DEFAULT 'balanced';
