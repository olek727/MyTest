-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "zipDownloadedAt" TIMESTAMP(3);
