-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "referrer" TEXT NOT NULL DEFAULT 'unknown';
