<p align=center>
  <img height="80px" src="https://user-images.githubusercontent.com/1536647/77317442-78625700-6d0b-11ea-9822-0fb21e557e87.png"/>
</p>

# 🐝🚀 Wasp Hackathon Submission App

This app was created for Wasp's Beta Hackathon (aka Betathon), so that participants would have a central place to learn about the hackathon and submit their projects. The app was deployed to Railway.app and is live [here](https://betathon-production.up.railway.app/). 

Visit the homepage to get started with [Wasp](https://wasp-lang.dev).

Feel free to use this as a template for your own Hackathons!