{{={= =}=}}

{=# cruds =}
  export type { {= name =} } from './{= name =}';
{=/ cruds =}
