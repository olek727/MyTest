// todo(filip): turn into a proper import/path
export type { ProviderName } from 'wasp/server/_types' 
