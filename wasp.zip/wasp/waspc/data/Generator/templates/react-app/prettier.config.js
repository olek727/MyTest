// Used for internal Wasp development only, not copied to generated app.
module.exports = {
  trailingComma: 'es5',
  tabWidth: 2,
  semi: false,
  singleQuote: true,
}
