-- CreateTable
CREATE TABLE "Dummy" (
    "id" SERIAL NOT NULL,

    PRIMARY KEY ("id")
);
