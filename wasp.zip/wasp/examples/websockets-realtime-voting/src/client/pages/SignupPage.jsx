import { SignupForm } from "wasp/client/auth";

export function SignupPage() {
  return <SignupForm />
}