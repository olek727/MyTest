# Security Policy

## Supported Versions

List of versions that are receiving security updates:

We are currently in pre-production stage so only the latest major release is receiving security updates!

## Reporting a Vulnerability

Please report any vulnerabilities at hi@wasp-lang.dev !
