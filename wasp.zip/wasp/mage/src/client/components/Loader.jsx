import "./Loader.css";

export function Loader() {
  return (
    <div className="loader-1">
      <span></span>
    </div>
  );
}
