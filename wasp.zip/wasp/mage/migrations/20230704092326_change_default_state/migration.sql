-- AlterTable
ALTER TABLE "Project" ALTER COLUMN "status" SET DEFAULT 'pending';
