-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "authMethod" TEXT NOT NULL DEFAULT 'usernameAndPassword';
