-- CreateIndex
CREATE INDEX "File_name_projectId_idx" ON "File"("name", "projectId");
