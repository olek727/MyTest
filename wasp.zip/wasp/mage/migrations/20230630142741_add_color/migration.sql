-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "primaryColor" TEXT NOT NULL DEFAULT 'sky';
