To run the deploy package as a standalone TS project, run:
```sh
npm install
npm run build
node dist/index.js fly ...
```
