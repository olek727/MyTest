import { CommonOptions, DbOptions } from '../CommonOptions.js';

export interface CreateDbOptions extends CommonOptions, DbOptions {}
