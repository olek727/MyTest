import { CommonOptions, SecretsOptions } from '../CommonOptions.js';

export interface SetupOptions extends CommonOptions, SecretsOptions { }
