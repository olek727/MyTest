{{={= =}=}}
{=# cruds =}
  export { {= name =} } from './{= name =}';
{=/ cruds =}
