`npm start` to run server in development mode (it reloads on changes).

`npm run debug` to run `npm start` with debug logs enabled.

`npm run standard` to run StandardJS.
