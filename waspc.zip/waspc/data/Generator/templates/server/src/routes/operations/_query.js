{{={= =}=}}
import { createQuery } from '../../middleware/operations.js'
{=& operation.importStatement =}

export default createQuery({= operation.importIdentifier =})
