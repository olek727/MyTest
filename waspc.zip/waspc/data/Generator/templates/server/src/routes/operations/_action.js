{{={= =}=}}
import { createAction } from '../../middleware/operations.js'
{=& operation.importStatement =}

export default createAction({= operation.importIdentifier =})
