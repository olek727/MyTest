import Todo from '../Todo'

const Main = () => {
  return <Todo />
}

export default Main
