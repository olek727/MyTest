-- AlterTable
ALTER TABLE "User" ADD COLUMN     "address" TEXT;
