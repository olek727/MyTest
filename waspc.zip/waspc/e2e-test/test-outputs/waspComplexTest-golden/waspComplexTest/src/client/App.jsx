export default function App({ children }) {
  return (
    <div className="app">
      <h1>Root component</h1>
      {children}
    </div>
  );
}

