export default function myClientSetupFunction() {
  // Do some client setup here.
}

