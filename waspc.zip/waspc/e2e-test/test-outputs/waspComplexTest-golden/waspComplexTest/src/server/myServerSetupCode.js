export default function mySetupFunction() {
  // Do some server setup here.
}

