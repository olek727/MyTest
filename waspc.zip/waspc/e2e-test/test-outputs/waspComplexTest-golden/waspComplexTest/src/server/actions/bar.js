export const foo = async (args) => {
  return 1
}

