import { MiddlewareConfigFn } from 'wasp/server'
export const fooBarNamespaceMiddlewareFn: MiddlewareConfigFn = (middlewareConfig) => {
  return middlewareConfig
}

